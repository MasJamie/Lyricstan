﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Models;
using DataAccess.Mapings;
using System.Data.Entity;

namespace DataAccess
{
    public class LyricContext : DbContext
    {
        public LyricContext()
            : base("LyricContext")
        {
        }

        public DbSet<Albume> Albumes { get; set; }
        public DbSet<Artist> Artists { get; set; }
        public DbSet<Country> Countries { set; get; }
        public DbSet<Genre> Genrs { get; set; }
        public DbSet<Language> Languages { get; set; }
        public DbSet<Music> Musics { get; set; }
        public DbSet<Rate> Rate { get; set; }
        public DbSet<Translate> Translates { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Artist_Music> Artist_Musics { get; set; }
        public DbSet<Favorite> Favorits { get; set; }
        public DbSet<Language_Music> Language_Musics { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new AlbumeMapping());
            modelBuilder.Configurations.Add(new ArtistMaping());
            modelBuilder.Configurations.Add(new CountryMapping());
            modelBuilder.Configurations.Add(new GenreMapping());
            modelBuilder.Configurations.Add(new LanguageMapping());
            modelBuilder.Configurations.Add(new MusicMapping());
            modelBuilder.Configurations.Add(new TranslateMapping());
            modelBuilder.Configurations.Add(new UserMapping());
            modelBuilder.Configurations.Add(new RateMapping());
            modelBuilder.Configurations.Add(new Artist_MusicMapping());
            modelBuilder.Configurations.Add(new FavoriteMapping());

        }
    }
}
