﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.MetaData
{
    public class ArtistMetadata
    {
        [Key]
        public virtual Guid ID { get; set; }
        [Required]
        [StringLength(30,MinimumLength=3)]
        [Display(Name="Artist")]
        public virtual string ArtistName { get; set; }
        [DataType(DataType.Url)]
        [Display(Name = "Facebook")]
        public virtual string FacebookUrl { get; set; }
        [DataType(DataType.Url)]
        [Display(Name = "Twitter")]
        public virtual string TwitterUrl { get; set; }
        [DataType(DataType.ImageUrl)]
        [Display(Name = "Picture")]
        public virtual string pictureUrl { get; set; }
        [DataType(DataType.Url)]
        [Display(Name = "Site")]
        public virtual string SiteUrl { get; set; }
    }
}
