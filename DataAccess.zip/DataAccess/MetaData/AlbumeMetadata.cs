﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.MetaData
{
    public class AlbumeMetadata
    {
        [Display(Name="Albume name")]
        [Required]
        [StringLength(30,MinimumLength=3)]
        public virtual string AlbumeName { get; set; }
        [Display(Name = "Picture of albume")]
        [DataType(DataType.ImageUrl)]
        public virtual string AlbumeArtUrl { get; set; }
        [Display(Name = "Publish year")]
        public virtual string PublishYear { get; set; }
        [Display(Name = "Description")]
        public virtual string Description { get; set; }

    }
}
