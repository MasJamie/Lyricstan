﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.MetaData
{
    public class RateMetadata
    {
        [Key]
        public virtual Guid ID { get; set; }
        [Required]
        public virtual Guid MusicID { get; set; }
        [Required]
        public virtual Guid UserID { get; set; }
        [Range(1,5)]
        [Required]
        public virtual int RateNumber { get; set; }
    }
}
