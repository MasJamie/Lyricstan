﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace DataAccess.MetaData
{
    public class LanguageMusicMetadata
    {
        [Key]
        public virtual Guid ID { get; set; }
        [Required]
        public virtual Guid MusicID { get; set; }
        [Required]
        public virtual int LanguageID { get; set; }
    }
}
