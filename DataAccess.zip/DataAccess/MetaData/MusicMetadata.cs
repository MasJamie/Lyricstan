﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace DataAccess.MetaData
{
    public class MusicMetadata
    {
        [Key]
        public virtual Guid ID { get; set; }
        [Required]
        [StringLength(30,MinimumLength=2)]
        [Display(Name="Music")]
        public virtual string MusicName { get; set; }
        public virtual string PublishDate { get; set; }
        [DataType(DataType.ImageUrl)]
        [Display(Name = "Cover pic")]
        public virtual string CoverUrl { get; set; }
        [DataType(DataType.Url)]
        [Display(Name = "Video Link")]
        public virtual string VideoUrl { get; set; }
        [DataType(DataType.Url)]
        [Display(Name = "Download link")]
        public virtual string DownloadUrl { get; set; }
        [DataType(DataType.MultilineText)]
        public virtual string Lyric { get; set; }
    }
}