﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace DataAccess.MetaData
{
    public class ArtistMusicMetadata
    {
        [Key]
        public virtual int ID { get; set; }
        [Required]
        public virtual Guid MusicID { get; set; }
        [Required]
        public virtual Guid ArtistID { get; set; }
    }
}
