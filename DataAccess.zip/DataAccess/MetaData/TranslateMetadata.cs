﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.MetaData
{
    public class TranslateMetadata
    {
        [Key]
        public virtual Guid ID { get; set; }
        [Required]
        public virtual Guid MusicID { get; set; }
        [Required]
        public virtual int LanguageID { get; set; }
        [Required]
        [DataType(DataType.MultilineText)]
        public virtual string LyricTranslate { get; set; }
    }
}
