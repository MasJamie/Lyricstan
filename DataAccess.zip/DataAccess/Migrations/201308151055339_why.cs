namespace DataAccess.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class why : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Translates", "LyricTranslate", c => c.String(nullable: false));
            DropColumn("dbo.Translates", "Description");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Translates", "Description", c => c.String(nullable: false));
            DropColumn("dbo.Translates", "LyricTranslate");
        }
    }
}
