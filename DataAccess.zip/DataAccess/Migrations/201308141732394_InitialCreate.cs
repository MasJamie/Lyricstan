namespace DataAccess.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Albumes",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        ArtistID = c.Guid(nullable: false),
                        AlbumeName = c.String(nullable: false, maxLength: 50),
                        AlbumeArtUrl = c.String(),
                        PublishYear = c.String(),
                        Description = c.String(maxLength: 200),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Artists", t => t.ArtistID, cascadeDelete: true)
                .Index(t => t.ArtistID);
            
            CreateTable(
                "dbo.Artists",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        CountryID = c.Int(nullable: false),
                        ArtistName = c.String(nullable: false, maxLength: 30),
                        FacebookUrl = c.String(),
                        TwitterUrl = c.String(),
                        pictureUrl = c.String(),
                        SiteUrl = c.String(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Countries", t => t.CountryID, cascadeDelete: true)
                .Index(t => t.CountryID);
            
            CreateTable(
                "dbo.Countries",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        CountryName = c.String(nullable: false, maxLength: 20),
                        FlagURL = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.Artist_Music",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        MusicID = c.Guid(nullable: false),
                        ArtistID = c.Guid(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Musics", t => t.MusicID, cascadeDelete: true)
                .ForeignKey("dbo.Artists", t => t.ArtistID, cascadeDelete: true)
                .Index(t => t.MusicID)
                .Index(t => t.ArtistID);
            
            CreateTable(
                "dbo.Musics",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        AlbumeID = c.Guid(nullable: false),
                        GenreID = c.Int(nullable: false),
                        PublishDate = c.String(maxLength: 10),
                        CoverUrl = c.String(),
                        VideoUrl = c.String(),
                        DownloadUrl = c.String(),
                        Lyric = c.String(nullable: false),
                        MusicName = c.String(nullable: false, maxLength: 30),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Genres", t => t.GenreID, cascadeDelete: true)
                .ForeignKey("dbo.Albumes", t => t.AlbumeID)
                .Index(t => t.GenreID)
                .Index(t => t.AlbumeID);
            
            CreateTable(
                "dbo.Genres",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        GenreName = c.String(nullable: false, maxLength: 20),
                        Description = c.String(nullable: false, maxLength: 200),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.Language_Music",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        MusicID = c.Guid(nullable: false),
                        LanguageID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Languages", t => t.LanguageID, cascadeDelete: true)
                .ForeignKey("dbo.Musics", t => t.MusicID, cascadeDelete: true)
                .Index(t => t.LanguageID)
                .Index(t => t.MusicID);
            
            CreateTable(
                "dbo.Languages",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        languageName = c.String(nullable: false, maxLength: 30),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.Translates",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        MusicID = c.Guid(nullable: false),
                        LanguageID = c.Int(nullable: false),
                        Description = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Languages", t => t.LanguageID, cascadeDelete: true)
                .ForeignKey("dbo.Musics", t => t.MusicID, cascadeDelete: true)
                .Index(t => t.LanguageID)
                .Index(t => t.MusicID);
            
            CreateTable(
                "dbo.Favorites",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        UserID = c.Guid(nullable: false),
                        MusicID = c.Guid(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Users", t => t.UserID, cascadeDelete: true)
                .ForeignKey("dbo.Musics", t => t.MusicID, cascadeDelete: true)
                .Index(t => t.UserID)
                .Index(t => t.MusicID);
            
            CreateTable(
                "dbo.Users",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        UserID = c.Guid(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.Rates",
                c => new
                    {
                        ID = c.Guid(nullable: false),
                        MusicID = c.Guid(nullable: false),
                        UserID = c.Guid(nullable: false),
                        RateNumber = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.Users", t => t.UserID, cascadeDelete: true)
                .ForeignKey("dbo.Musics", t => t.MusicID, cascadeDelete: true)
                .Index(t => t.UserID)
                .Index(t => t.MusicID);
            
        }
        
        public override void Down()
        {
            DropIndex("dbo.Rates", new[] { "MusicID" });
            DropIndex("dbo.Rates", new[] { "UserID" });
            DropIndex("dbo.Favorites", new[] { "MusicID" });
            DropIndex("dbo.Favorites", new[] { "UserID" });
            DropIndex("dbo.Translates", new[] { "MusicID" });
            DropIndex("dbo.Translates", new[] { "LanguageID" });
            DropIndex("dbo.Language_Music", new[] { "MusicID" });
            DropIndex("dbo.Language_Music", new[] { "LanguageID" });
            DropIndex("dbo.Musics", new[] { "AlbumeID" });
            DropIndex("dbo.Musics", new[] { "GenreID" });
            DropIndex("dbo.Artist_Music", new[] { "ArtistID" });
            DropIndex("dbo.Artist_Music", new[] { "MusicID" });
            DropIndex("dbo.Artists", new[] { "CountryID" });
            DropIndex("dbo.Albumes", new[] { "ArtistID" });
            DropForeignKey("dbo.Rates", "MusicID", "dbo.Musics");
            DropForeignKey("dbo.Rates", "UserID", "dbo.Users");
            DropForeignKey("dbo.Favorites", "MusicID", "dbo.Musics");
            DropForeignKey("dbo.Favorites", "UserID", "dbo.Users");
            DropForeignKey("dbo.Translates", "MusicID", "dbo.Musics");
            DropForeignKey("dbo.Translates", "LanguageID", "dbo.Languages");
            DropForeignKey("dbo.Language_Music", "MusicID", "dbo.Musics");
            DropForeignKey("dbo.Language_Music", "LanguageID", "dbo.Languages");
            DropForeignKey("dbo.Musics", "AlbumeID", "dbo.Albumes");
            DropForeignKey("dbo.Musics", "GenreID", "dbo.Genres");
            DropForeignKey("dbo.Artist_Music", "ArtistID", "dbo.Artists");
            DropForeignKey("dbo.Artist_Music", "MusicID", "dbo.Musics");
            DropForeignKey("dbo.Artists", "CountryID", "dbo.Countries");
            DropForeignKey("dbo.Albumes", "ArtistID", "dbo.Artists");
            DropTable("dbo.Rates");
            DropTable("dbo.Users");
            DropTable("dbo.Favorites");
            DropTable("dbo.Translates");
            DropTable("dbo.Languages");
            DropTable("dbo.Language_Music");
            DropTable("dbo.Genres");
            DropTable("dbo.Musics");
            DropTable("dbo.Artist_Music");
            DropTable("dbo.Countries");
            DropTable("dbo.Artists");
            DropTable("dbo.Albumes");
        }
    }
}
