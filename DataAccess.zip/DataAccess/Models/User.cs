﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using DataAccess.MetaData;

namespace DataAccess.Models
{
    [MetadataType(typeof(UserMetadata))]
    public class User
    {
        public virtual Guid ID { get; set; }
        public virtual Guid UserID { set; get; }
        public virtual List<Favorite> Favorite { get; set; }
        public virtual List<Rate> Rate { get; set; }
    }
}
