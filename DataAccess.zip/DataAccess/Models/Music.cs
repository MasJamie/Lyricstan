﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using DataAccess.MetaData;

namespace DataAccess.Models
{
    [MetadataType(typeof(Music))]
    public class Music
    {
        public virtual Guid ID { get; set; }
        public virtual Guid AlbumeID { get; set; }
        public virtual int GenreID { get; set; }
        public virtual string PublishDate { get; set; }
        public virtual string CoverUrl { get; set; }
        public virtual string VideoUrl { get; set; }
        public virtual string DownloadUrl { get; set; }
        public virtual string Lyric { get; set; }
        public virtual string MusicName { get; set; }
        public virtual Genre Genre { get; set; }
        public virtual Albume Albume { get; set; }
        public virtual List<Artist_Music> Artist_Music { get; set; }
        public virtual List<Language_Music> Language_Music { get; set; }
        public virtual List<Translate> Translate { get; set; }
        public virtual List<Favorite> Favorite { get; set; }
        public virtual List<Rate> Rate { get; set; }
    }
}
