﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Threading.Tasks;
using DataAccess.MetaData;

namespace DataAccess.Models
{
    [MetadataType(typeof(ArtistMusicMetadata))]
    public class Artist_Music
    {
        public virtual int ID { get; set; }
        public virtual Guid MusicID { get; set; }
        public virtual Guid ArtistID { get; set; }
        public virtual Music Music { get; set; }
        public virtual Artist Artist { get; set; }
    }
}
