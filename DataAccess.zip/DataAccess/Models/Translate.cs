﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using DataAccess.MetaData;

namespace DataAccess.Models
{
    [MetadataType(typeof(TranslateMetadata))]
    public class Translate
    {
        public virtual Guid ID { get; set; }
        public virtual Guid MusicID { get; set; }
        public virtual int LanguageID { get; set; }
        public virtual string LyricTranslate { get; set; }
        public virtual Music Music { get; set; }
        public virtual Language Language { get; set; }
    }
}
