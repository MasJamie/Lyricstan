﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using DataAccess.MetaData;

namespace DataAccess.Models
{
    [MetadataType(typeof(ArtistMetadata))]
    public class Artist
    {
        public virtual Guid ID { get; set; }
        public virtual int CountryID { get; set; }
        public virtual string ArtistName { get; set; }
        public virtual string FacebookUrl { get; set; }
        public virtual string TwitterUrl { get; set; }
        public virtual string pictureUrl { get; set; }
        public virtual string SiteUrl { get; set; }
        public virtual Country country { get; set; }
        public virtual List<Albume> Albume { get; set; }
        public virtual List<Artist_Music> Artist_Music { set; get; }
    }
}
