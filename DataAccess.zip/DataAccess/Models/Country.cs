﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Text;
using System.Threading.Tasks;
using DataAccess.MetaData;

namespace DataAccess.Models
{
    [MetadataType(typeof(CountryMetadata))]
    public class Country
    {
        public virtual int ID { get; set; }
        public virtual string CountryName { get; set; }
        public virtual string FlagURL { get; set; }
       public virtual List<Artist> Artist { get; set; }

        //public void test()
        //{
        //    LyricContex db = new LyricContex();
            
        //}
    }
}
