﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models
{
    public class Language
    {
        public virtual int ID { get; set; }
        public virtual string languageName { get; set; }
        public virtual List<Language_Music> Language_Music { get; set; }
        public virtual List<Translate> Translate { set; get; }
    }
}
