﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using DataAccess.MetaData;

namespace DataAccess.Models
{
    [MetadataType(typeof(RateMetadata))]
    public class Rate
    {
        public virtual Guid ID { get; set; }
        public virtual Guid MusicID { get; set; }
        public virtual Guid UserID { get; set; }
        public virtual int RateNumber { get; set; }
        public virtual Music Music { get; set; }
        public virtual User User { get; set; }
    }
}
