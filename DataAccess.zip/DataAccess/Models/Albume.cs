﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Threading.Tasks;
using DataAccess.MetaData;

namespace DataAccess.Models
{
    [MetadataType(typeof(AlbumeMetadata))]
    public class Albume
    {
        public virtual Guid ID { get; set; }
        public virtual Guid ArtistID { get; set; }
        public virtual string AlbumeName { get; set; }
        public virtual string AlbumeArtUrl { get; set; }
        public virtual string PublishYear { get; set; }
        public virtual string Description { get; set; }
        public virtual Artist Artist { get; set; }
        public virtual List<Music> Music { get; set; }
    }
}
