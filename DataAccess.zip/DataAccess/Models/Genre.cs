﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Threading.Tasks;
using DataAccess.MetaData;

namespace DataAccess.Models
{
    [MetadataType(typeof(GenreMetadata))]
    public class Genre
    {
        public virtual int ID { get; set; }
        public virtual string GenreName { get; set; }
        public virtual string Description { get; set; }
        public virtual List<Music> Music { get; set; }
    }
}
