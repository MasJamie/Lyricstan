﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity.ModelConfiguration;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Models;

namespace DataAccess.Mapings
{
    class CountryMapping:EntityTypeConfiguration<Country>
    {
        public CountryMapping()
        {
            HasKey(x => x.ID);

            Property(x => x.CountryName).IsRequired().HasMaxLength(20);

            Property(x => x.FlagURL).IsRequired();

            HasMany(x => x.Artist).WithRequired(x => x.country).HasForeignKey(x => x.CountryID);
        }
    }
}
