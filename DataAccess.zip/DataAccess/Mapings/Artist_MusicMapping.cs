﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity.ModelConfiguration;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Models;

namespace DataAccess.Mapings
{
    public class Artist_MusicMapping : EntityTypeConfiguration<Artist_Music>
    {
        public Artist_MusicMapping()
        {
            HasKey(x => x.ID);

            HasRequired(x => x.Music).WithMany(x => x.Artist_Music).HasForeignKey(x => x.MusicID);

            HasRequired(x => x.Artist).WithMany(x => x.Artist_Music).HasForeignKey(x => x.ArtistID);
        }
    }
}
