﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity.ModelConfiguration;
using System.Threading.Tasks;
using DataAccess.Models;

namespace DataAccess.Mapings
{
    public class Language_MusicMapping:EntityTypeConfiguration<Language_Music>
    {
        public Language_MusicMapping()
        {
            HasKey(x => x.ID);

            HasRequired(x => x.Music).WithMany(x => x.Language_Music).HasForeignKey(x => x.MusicID);

            HasRequired(x => x.Language).WithMany(x => x.Language_Music).HasForeignKey(x => x.LanguageID);
        }
    }
}
