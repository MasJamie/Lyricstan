﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity.ModelConfiguration;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Models;

namespace DataAccess.Mapings
{
    public class ArtistMaping : EntityTypeConfiguration<Artist>
    {
        public ArtistMaping()
        {
            HasKey(x => x.ID);

            Property(x => x.ArtistName).IsRequired().HasMaxLength(30);

            Property(x => x.FacebookUrl);

            Property(x => x.TwitterUrl);

            Property(x => x.SiteUrl);

            Property(x => x.pictureUrl);

            HasRequired(x => x.country).WithMany(y => y.Artist).HasForeignKey(x => x.CountryID);

            HasMany(x => x.Artist_Music).WithRequired(x => x.Artist).HasForeignKey(x => x.ArtistID);
        }
    }
}
