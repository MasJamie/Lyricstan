﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity.ModelConfiguration;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Models;

namespace DataAccess.Mapings
{
    public class LanguageMapping:EntityTypeConfiguration<Language>
    {
        public LanguageMapping()
        {
            HasKey(x => x.ID);

            Property(x => x.languageName).IsRequired().HasMaxLength(30);

            HasMany(x => x.Language_Music).WithRequired(x => x.Language).HasForeignKey(x => x.LanguageID);
        }
    }
}
