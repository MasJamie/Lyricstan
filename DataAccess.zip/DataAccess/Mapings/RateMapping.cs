﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity.ModelConfiguration;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Models;

namespace DataAccess.Mapings
{
    public class RateMapping:EntityTypeConfiguration<Rate>
    {
        public RateMapping()
        {
            HasKey(x => x.ID);

            Property(x => x.RateNumber).IsRequired();

            HasRequired(x => x.Music).WithMany(x => x.Rate).HasForeignKey(x => x.MusicID);

            HasRequired(x => x.User).WithMany(x => x.Rate).HasForeignKey(x => x.UserID);
        }
    }
}
