﻿using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Models;

namespace DataAccess.Mapings
{
    public class AlbumeMapping:EntityTypeConfiguration<Albume>
    {
        public AlbumeMapping()
        {
            HasKey(x => x.ID);

            Property(x => x.AlbumeName).IsRequired().HasMaxLength(50);

            Property(x => x.AlbumeArtUrl);

            Property(x => x.PublishYear);

            Property(x => x.Description).HasMaxLength(200);

            HasRequired(x => x.Artist).WithMany(y => y.Albume).HasForeignKey(x => x.ArtistID);

            HasMany(x => x.Music).WithRequired(x => x.Albume).HasForeignKey(x => x.AlbumeID).WillCascadeOnDelete(false);

            
        }
    }
}
