﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity.ModelConfiguration;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Models;

namespace DataAccess.Mapings
{
    public class UserMapping:EntityTypeConfiguration<User>
    {
        public UserMapping()
        {
            HasKey(x => x.ID);

            Property(x => x.UserID);

            HasMany(x => x.Rate).WithRequired(x => x.User).HasForeignKey(x => x.UserID);

            HasMany(x => x.Favorite).WithRequired(x => x.User).HasForeignKey(x => x.UserID);
        }
    }
}
