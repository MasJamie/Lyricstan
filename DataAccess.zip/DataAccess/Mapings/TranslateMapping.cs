﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity.ModelConfiguration;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Models;

namespace DataAccess.Mapings
{
    public class TranslateMapping:EntityTypeConfiguration<Translate>
    {
        public TranslateMapping()
        {
            HasKey(x => x.ID);

            Property(x => x.LyricTranslate).IsRequired();

            HasRequired(x => x.Music).WithMany(y => y.Translate).HasForeignKey(x => x.MusicID);

            HasRequired(x => x.Language).WithMany(y => y.Translate).HasForeignKey(x => x.LanguageID);
        }
    }
}
