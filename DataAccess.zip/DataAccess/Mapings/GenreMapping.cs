﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity.ModelConfiguration;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Models;

namespace DataAccess.Mapings
{
    public class GenreMapping:EntityTypeConfiguration<Genre>
    {
        public GenreMapping()
        {
            HasKey(x => x.ID);

            Property(x => x.GenreName).IsRequired().HasMaxLength(20);

            Property(x => x.Description).IsRequired().HasMaxLength(200);

            HasMany(x => x.Music).WithRequired(x => x.Genre).HasForeignKey(x => x.GenreID);
        }
    }
}
