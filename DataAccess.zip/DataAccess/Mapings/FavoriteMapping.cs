﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity.ModelConfiguration;
using System.Threading.Tasks;
using DataAccess.Models;

namespace DataAccess.Mapings
{
    public class FavoriteMapping:EntityTypeConfiguration<Favorite>
    {
        public FavoriteMapping()
        {
            HasKey(x => x.ID);

            HasRequired(x => x.User).WithMany(x => x.Favorite).HasForeignKey(x => x.UserID);

            HasRequired(x => x.Music).WithMany(x => x.Favorite).HasForeignKey(x => x.MusicID);
        }
    }
}
