﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity.ModelConfiguration;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Models;

namespace DataAccess.Mapings
{
    public class MusicMapping : EntityTypeConfiguration<Music>
    {
        public MusicMapping()
        {
            HasKey(x => x.ID);

            Property(x => x.PublishDate).HasMaxLength(10);

            Property(x => x.CoverUrl);

            Property(x => x.DownloadUrl);

            Property(x => x.MusicName).IsRequired().HasMaxLength(30);

            Property(x => x.Lyric).IsRequired();

            Property(x => x.VideoUrl);

            HasRequired(x => x.Genre).WithMany(y => y.Music).HasForeignKey(x => x.GenreID);

            HasRequired(x => x.Albume).WithMany(y => y.Music).HasForeignKey(x => x.AlbumeID).WillCascadeOnDelete(false);

            HasMany(x => x.Translate).WithRequired(x => x.Music).HasForeignKey(x => x.MusicID);

            HasMany(x => x.Rate).WithRequired(x => x.Music).HasForeignKey(x => x.MusicID);

            HasMany(x => x.Artist_Music).WithRequired(x => x.Music).HasForeignKey(x => x.MusicID);

            HasMany(x => x.Language_Music).WithRequired(x => x.Music).HasForeignKey(x => x.MusicID);

            HasMany(x => x.Favorite).WithRequired(x => x.Music).HasForeignKey(x => x.MusicID);

        }
    }
}
