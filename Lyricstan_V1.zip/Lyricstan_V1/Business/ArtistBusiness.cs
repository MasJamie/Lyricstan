﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using DataAccess.Models;
using System.Data.Entity.Infrastructure;
using System.Data;
namespace Business
{
    public class ArtistBusiness
    {
        LyricContext db = new LyricContext();

        public void AddArtist(Artist artist)
        {
            db.Artists.Add(artist);
            db.SaveChanges();
        }

        public void EditArtist(Artist artist)
        {
            Artist exist=db.Artists.Find(artist.ID);
            ((IObjectContextAdapter)db).ObjectContext.Detach(exist);
            db.Entry(artist).State = EntityState.Modified;
            db.SaveChanges();
        }

        public void DeleteArtist(int id)
        {
            Artist exist = db.Artists.Find(id);
            db.Artists.Remove(exist);
            db.SaveChanges();
        }

        public IEnumerable<Artist> ReadArtist()
        {
            var artist = from A in db.Artists
                         select A;
            return artist;
        }

        public Artist ReadArtist(Guid id)
        {
            return db.Artists.Find(id);
        }

        public IEnumerable<Artist> SearchArtist(string artistName, int countryID)
        {
            var artist = from A in db.Artists
                         select A;
            artist = (artist.Where(x => x.ArtistName.Contains(artistName) && x.CountryID == countryID));
            return artist;
        }

        public IEnumerable<Artist> ReadArtist(string ArtistName)
        {
            var artists = from a in db.Artists
                          where a.ArtistName.Contains(ArtistName)
                          select a;
            return artists;
        }
    }
}

