﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using DataAccess.Models;
using System.Data.Entity.Infrastructure;
using System.Data;

namespace Business
{
    public class AlbumeBusiness
    {
        private LyricContext db = new LyricContext();
        public bool AddAlbume(Albume albume)
        {
            if(!db.Albumes.Any(x=>x.ArtistID==albume.ArtistID && x.AlbumeName==albume.AlbumeName))
            {
                db.Albumes.Add(albume);
                db.SaveChanges();
                return true;
            }
            return false;
        }

        public bool EditAlbume(Albume albume)
        {
            Albume exist = db.Albumes.Find(albume.ID);
            if (albume.AlbumeName == exist.AlbumeName && albume.ArtistID == exist.ArtistID)
            {
                ((IObjectContextAdapter)db).ObjectContext.Detach(exist);
                db.Entry(albume).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            if (!db.Albumes.Any(x => x.ArtistID == albume.ArtistID && x.AlbumeName == albume.AlbumeName))
            {

                ((IObjectContextAdapter)db).ObjectContext.Detach(exist);
                db.Entry(albume).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            return false;
        }

        public IEnumerable<Albume> ReadAlbume()
        {
            var albume = from A in db.Albumes
                         select A;
            return albume;
        }

        public Albume ReadAlbume(Guid id)
        {
            return db.Albumes.Find(id);
        }

        public IEnumerable<Albume> ReadAlbumeForArtist(Guid id)
        {
            Music music = db.Musics.Find(id);
            Albume albume =db.Albumes.Find(music.AlbumeID);

            var albumes = from a in db.Albumes
                          where a.ArtistID == albume.ArtistID
                          select a;
            return albumes;
        }
    }
}
