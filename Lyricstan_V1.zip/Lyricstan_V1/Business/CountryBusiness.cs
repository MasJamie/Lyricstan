﻿using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using DataAccess.Models;
using System.Data;
using System.Data.Entity.Infrastructure;

namespace Business
{
    public class CountryBusiness
    {
        LyricContext db = new LyricContext();

        public bool AddCountry(Country country) 
        {
            if (!db.Countries.AsEnumerable().Any(x => x.CountryName == country.CountryName))
            {
                db.Countries.Add(country);
                db.SaveChanges();
                return true;
            }
            return false;
        }

        public bool EditCountry(Country country)
        {
            Country exist = db.Countries.Find(country.ID);
            if (country.CountryName == exist.CountryName)
            {
                ((IObjectContextAdapter)db).ObjectContext.Detach(exist);
                db.Entry(country).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            if (!db.Countries.AsEnumerable().Any(x => x.CountryName == country.CountryName))
            {
                ((IObjectContextAdapter)db).ObjectContext.Detach(exist);
                db.Entry(country).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            return false;
        }

        public IEnumerable<Country> ReadCountries()
        {
            var countri = db.Countries.ToList();
            return countri;
        }

        public Country ReadCountry(int id)
        {
            return db.Countries.Find(id);
        }

        public bool ReadCountries(int ID)
        {
            var countri = db.Countries.Find(ID);
            if (countri == null)
                return true;
            return false;
        }

        public IEnumerable<Country> SearchCountry(string Search)
        {
            var countrys = from C in db.Countries
                           select C;
            countrys = countrys.Where(c => c.CountryName.Contains(Search));
            return countrys;
        }

    }
}
