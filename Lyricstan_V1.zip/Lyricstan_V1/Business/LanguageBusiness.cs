﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.Infrastructure;
using System.Data;
using DataAccess.Models;
using DataAccess;

namespace Business
{
    public class LanguageBusiness
    {
        LyricContext db = new LyricContext();

        public bool AddLanguage(Language language)
        {
            if(!db.Languages.Any(x=>x.languageName==language.languageName))
            {
                db.Languages.Add(language);
                db.SaveChanges();
                return true;
            }
            return false;
        }

        public bool EditLanguage(Language language)
        {
            Language exist = db.Languages.Find(language.ID);
            if (language.languageName == exist.languageName)
            {
                ((IObjectContextAdapter)db).ObjectContext.Detach(exist);
                db.Entry(language).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            if (!db.Languages.Any(x => x.languageName == language.languageName))
            {
                ((IObjectContextAdapter)db).ObjectContext.Detach(exist);
                db.Entry(language).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            return false;
        }

        public IEnumerable<Language> ReadLanguage()
        {
            var language = from L in db.Languages
                           select L;
            return language;
        }

        public IEnumerable<Language> SearchLanguage(string Search)
        {
            var language = from L in db.Languages
                           select L;
            language = language.Where(x => x.languageName.Contains(Search));
            
            return language;
        }

        public Language ReadLanguage(int id)
        {
            return db.Languages.Find(id);
        }
    }
}
