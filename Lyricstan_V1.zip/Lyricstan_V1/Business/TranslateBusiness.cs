﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using DataAccess.Models;
using System.Data.Entity.Infrastructure;
using System.Data;

namespace Business
{
    public class TranslateBusiness
    {
        private LyricContext db = new LyricContext();

        public bool AddTranslate(Translate translate)
        {
            if (db.Translates.Any(x => x.MusicID==translate.MusicID))
            {
                if (db.Translates.Where(x => x.MusicID == translate.MusicID).Any
                    (x => x.LanguageID==translate.LanguageID))
                    return false;
                return Add(translate);
            }
            return Add(translate);
        }

        private bool Add(Translate translate)
        {
            db.Translates.Add(translate);
            db.SaveChanges();
            return true;
        }

        public bool EditTranslate(Translate translate)
        {
            Translate exist = db.Translates.Find(translate.ID);
            if (exist.MusicID == translate.MusicID && exist.LanguageID == translate.LanguageID)
            {
                return Edit(exist);
            }
            if (exist.MusicID != translate.MusicID)
            {
                if (db.Translates.Where(x => x.MusicID == translate.MusicID).Any
                    (x => x.LanguageID == translate.LanguageID))
                    return false;
                return Edit(translate);
            }

            return Edit(translate);

        }

        private bool Edit(Translate exist)
        {
            ((IObjectContextAdapter)db).ObjectContext.Detach(exist);
            db.Entry(exist).State = EntityState.Modified;
            db.SaveChanges();
            return true;
        }
    }
}
