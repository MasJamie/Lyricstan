﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using DataAccess.Models;

namespace Business
{
    public class RateBusiness
    {
        private LyricContext db = new LyricContext();

        public void AddRate(Rate rate)
        {
            if (Check(rate))
            {
                db.Rate.Add(rate);
                db.SaveChanges();
            }
        }

        public bool Check(Rate rate)
        {
            if(db.Rate.Where(x=>x.UserID == rate.UserID).Any(x=>x.MusicID==rate.MusicID))
                return false;
            return true;
        }
    }
}
