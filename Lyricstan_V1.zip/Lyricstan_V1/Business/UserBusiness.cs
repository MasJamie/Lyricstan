﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using DataAccess.Models;

namespace Business
{
    public class UserBusiness
    {
        private LyricContext db = new LyricContext();
        
        public void AddUser(Guid userID)
        {
            User user = new User();
            user.ID = new Guid();
            user.UserID = userID;
            db.Users.Add(user);
            db.SaveChanges();
        }
    }
}
