﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Entity.Infrastructure;
using DataAccess;
using DataAccess.Models;

namespace Business
{
    public class MusicBusiness
    {
        private LyricContext db = new LyricContext();

        public void AddMusic(Music music)
        {
            db.Musics.Add(music);
            db.SaveChanges();
        }

        public void EditMusic(Music music)
        {
            Music exist = db.Musics.Find(music.ID);
            ((IObjectContextAdapter)db).ObjectContext.Detach(exist);
            db.Entry(music).State = EntityState.Modified;
            db.SaveChanges();
        }

        public IEnumerable<Music> ReadMusic()
        {
            var music = from M in db.Musics
                        select M;
            return music;
        }

        public Music ReadMusic(Guid id)
        {
            return db.Musics.Find(id);
        }

        public IEnumerable<Music> ReadMusic(string Search)
        {
            var music = from m in db.Musics
                        where m.Lyric.Contains(Search)
                        select m;
            return music;
        }


    }
}
