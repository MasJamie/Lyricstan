﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Entity.Infrastructure;
using DataAccess;
using DataAccess.Models;

namespace Business
{
    public class ArtistMusicBusiness
    {
        private LyricContext db = new LyricContext();
        public bool AddArtistToMusic(Artist_Music artistMusic)
        {
            if (db.Artist_Musics.Any(x => x.MusicID==artistMusic.MusicID))
            {
                if (db.Artist_Musics.Where(x=>x.MusicID==artistMusic.MusicID).Any(x=>x.ArtistID==artistMusic.ArtistID))
                    return false;
                db.Artist_Musics.Add(artistMusic);
                db.SaveChanges();
                return true;
            }
            db.Artist_Musics.Add(artistMusic);
            db.SaveChanges();
            return true;
        }

        public bool EditArtistToMusic(Artist_Music artistMusic)
        {
            if (db.Artist_Musics.Where(x => x.MusicID == artistMusic.MusicID).Any(x => x.ArtistID == artistMusic.ArtistID))
                return false;
            Artist_Music exist = db.Artist_Musics.Find(artistMusic.ID);
            ((IObjectContextAdapter)db).ObjectContext.Detach(exist);
            db.Entry(artistMusic).State = EntityState.Modified;
            db.SaveChanges();
            return true;
        }
    }
}
