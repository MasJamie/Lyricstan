﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using DataAccess.Models;

namespace Business
{
    public class FavoriteBusiness
    {
        private LyricContext db=new LyricContext();
        public bool AddFavorite(Favorite favorite)
        {
            Favorite exist = db.Favorits.Find(favorite);
            if (exist.MusicID == favorite.MusicID)
                return false;
            db.Favorits.Add(favorite);
            db.SaveChanges();
            return true;
        }
        public void Deletefavorite(Guid ID)
        {
            Favorite exist = db.Favorits.Find(ID);
            db.Favorits.Remove(exist);
            db.SaveChanges();
        }
    }
}
