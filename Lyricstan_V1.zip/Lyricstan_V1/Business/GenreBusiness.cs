﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Entity.Infrastructure;
using System.Threading.Tasks;
using DataAccess.Models;
using DataAccess;

namespace Business
{
    public class GenreBusiness
    {
        LyricContext db = new LyricContext();

        public bool AddGenre(Genre genre)
        {
            if (!db.Genrs.Any(x => x.GenreName == genre.GenreName))
            {
                db.Genrs.Add(genre);
                db.SaveChanges();
                return true;
            }
            return false;
        }

        public bool EditGenre(Genre genre)
        {
            Genre exist = db.Genrs.Find(genre.ID);

            if (genre.GenreName == exist.GenreName)
            {
                ((IObjectContextAdapter)db).ObjectContext.Detach(exist);
                db.Entry(genre).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            if (!db.Genrs.Any(x => x.GenreName == genre.GenreName))
            {
                ((IObjectContextAdapter)db).ObjectContext.Detach(exist);
                db.Entry(genre).State = EntityState.Modified;
                db.SaveChanges();
                return true;
            }
            return false;
        }

        public bool DeleteGenre(int id)
        {
            Genre exist = db.Genrs.Find(id);
            if(exist==null)
                return false;
            db.Genrs.Remove(exist);
            db.SaveChanges();
            return true;
        }

        public IEnumerable<Genre> ReadGenrs()
        {
            var genres = from G in db.Genrs
                         select G;
            return genres;
        }

        public IEnumerable<Genre> SearchGenre(string Search)
        {
            var genres = from G in db.Genrs
                         select G;
            genres = genres.Where(x => x.GenreName.Contains(Search));
            return genres;

        }

        public Genre ReadGenrs(int id)
        {
            return db.Genrs.Find(id);
        }
    }
}
