﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Entity.Infrastructure;
using DataAccess.Models;
using DataAccess;

namespace Business
{
    public class LanguageMusicBussiness
    {
        private LyricContext db = new LyricContext();

        public bool AddLanguageToMusic(Language_Music language_Music)
        {
            if (db.Language_Musics.Any(x => x.MusicID == language_Music.MusicID))
            {
                if (db.Language_Musics.Where(x => x.MusicID == language_Music.MusicID).Any(x => x.LanguageID == language_Music.LanguageID))
                    return false;
                db.Language_Musics.Add(language_Music);
                db.SaveChanges();
                return true;
            }
            db.Language_Musics.Add(language_Music);
            db.SaveChanges();
            return true;
        }

        public bool EditLanguageToMusic(Language_Music language_Music)
        {
            if (db.Language_Musics.Where(x => x.MusicID == language_Music.MusicID).Any(x => x.LanguageID == language_Music.LanguageID))
                return false;
            Language_Music exist = db.Language_Musics.Find(language_Music.ID);
            ((IObjectContextAdapter)db).ObjectContext.Detach(exist);
            db.Entry(language_Music).State = EntityState.Modified;
            db.SaveChanges();
            return true;
        }
    }
}
