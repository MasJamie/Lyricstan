﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataAccess.Models;
using DataAccess;
using Business;
using Lyricstan_V1.ViewModel;

namespace Lyricstan_V1.Controllers
{
    public class TranslateController : Controller
    {
        private LyricContext db = new LyricContext();
        private MusicBusiness musicBiz = new MusicBusiness();
        private LanguageBusiness languageBiz = new LanguageBusiness();
        private TranslateBusiness translateBiz = new TranslateBusiness();

        //
        // GET: /Translate/

        public ActionResult Index()
        {
            var translates = db.Translates.Include(t => t.Music).Include(t => t.Language);
            return View(translates.ToList());
        }

        //
        // GET: /Translate/Details/5

        public ActionResult Details(Guid id)
        {
            Translate translate = db.Translates.Find(id);
            if (translate == null)
            {
                return HttpNotFound();
            }
            return View(translate);
        }

        //
        // GET: /Translate/Create

        public ActionResult Create()
        {
            var model = new TranslateViewModel()
            {
                LanguageList = languageBiz.ReadLanguage().Select(
                x => new SelectListItem { Value = x.ID.ToString(), Text = x.languageName }),
                MusicList = musicBiz.ReadMusic().Select(
                x => new SelectListItem { Value = x.ID.ToString(), Text = x.MusicName })
            };
            return View(model);
        }

        //
        // POST: /Translate/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(TranslateViewModel translate)
        {
            if (ModelState.IsValid)
            {
                Translate trans = new Translate();
                trans.ID = Guid.NewGuid();
                trans.MusicID = translate.MusicID;
                trans.LanguageID = translate.LanguageID;
                trans.LyricTranslate = translate.LyricTranslate;
                translateBiz.AddTranslate(trans);
                return RedirectToAction("Index");
            }
            return View(translate);
        }

        //
        // GET: /Translate/Edit/5

        public ActionResult Edit(Guid id)
        {
            Translate translate = db.Translates.Find(id);
            if (translate == null)
            {
                return HttpNotFound();
            }
            var model = new TranslateViewModel()
            {
                ID=translate.ID,
                LanguageList = languageBiz.ReadLanguage().Select(
                x => new SelectListItem { Value = x.ID.ToString(), Text = x.languageName }),
                LanguageID=translate.LanguageID,
                MusicList = musicBiz.ReadMusic().Select(
                x => new SelectListItem { Value = x.ID.ToString(), Text = x.MusicName }),
                MusicID=translate.ID
            };
            return View(model);
        }

        //
        // POST: /Translate/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Translate translate)
        {
            if (ModelState.IsValid)
            {
                Translate trans = new Translate();
                trans.ID = translate.ID;
                trans.MusicID = translate.MusicID;
                trans.LanguageID = translate.LanguageID;
                translateBiz.EditTranslate(trans);
                return RedirectToAction("Index");
            }

            return View(translate);
        }

        //
        // GET: /Translate/Delete/5

        public ActionResult Delete(Guid id)
        {
            Translate translate = db.Translates.Find(id);
            if (translate == null)
            {
                return HttpNotFound();
            }
            return View(translate);
        }

        //
        // POST: /Translate/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(Guid id)
        {
            Translate translate = db.Translates.Find(id);
            db.Translates.Remove(translate);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}