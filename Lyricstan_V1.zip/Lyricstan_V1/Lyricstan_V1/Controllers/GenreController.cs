﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataAccess.Models;
using DataAccess;
using Business;

namespace Lyricstan_V1.Controllers
{
    public class GenreController : Controller
    {
        private LyricContext db = new LyricContext();
        private GenreBusiness genreBiz = new GenreBusiness();

        //
        // GET: /GenreBusiness/

        public ActionResult Index(string Search)
        {
            if (Search == null)
                return View(db.Genrs.ToList());
            return View(genreBiz.SearchGenre(Search));
        }

        //
        // GET: /GenreBusiness/Details/5

        //
        // GET: /GenreBusiness/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /GenreBusiness/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Genre genre)
        {
            if (ModelState.IsValid)
            {
                if (genreBiz.AddGenre(genre))
                    return RedirectToAction("Index");
                ViewBag.Message = "this GenreBusiness already exist";
            }

            return View(genre);
        }

        //
        // GET: /GenreBusiness/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Genre genre = genreBiz.ReadGenrs(id);
            if (genre == null)
            {
                return HttpNotFound();
            }
            return View(genre);
        }

        //
        // POST: /GenreBusiness/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Genre genre)
        {
            if (ModelState.IsValid)
            {
                if (genreBiz.EditGenre(genre))
                    return RedirectToAction("Index");
                ViewBag.Message = "This GenreBusiness already exist";
            }
            return View(genre);
        }

        //
        // GET: /GenreBusiness/Delete/5

        public ActionResult Delete(int id = 0)
        {
            Genre genre = genreBiz.ReadGenrs(id);
            if (genre == null)
            {
                return HttpNotFound();
            }
            return View(genre);
        }

        //
        // POST: /GenreBusiness/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if(!genreBiz.DeleteGenre(id))
                ViewBag.Message = "There is something wrong";
            return RedirectToAction("Index");
        }
    }
}