﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataAccess.Models;
using DataAccess;
using Business;
using Lyricstan_V1.ViewModel;

namespace Lyricstan_V1.Controllers
{
    public class ArtistMusicController : Controller
    {
        private LyricContext db = new LyricContext();
        private MusicBusiness musicBiz = new MusicBusiness();
        private ArtistBusiness artistBiz = new ArtistBusiness();
        private ArtistMusicBusiness artMusicBiz = new ArtistMusicBusiness();

        //
        // GET: /ArtistMusic/

        public ActionResult Index()
        {
            var artist_musics = db.Artist_Musics.Include(a => a.Music).Include(a => a.Artist);
            return View(artist_musics.ToList());
        }

        //
        // GET: /ArtistMusic/Details/5

        public ActionResult Details(int id = 0)
        {
            Artist_Music artist_music = db.Artist_Musics.Find(id);
            if (artist_music == null)
            {
                return HttpNotFound();
            }
            return View(artist_music);
        }

        //
        // GET: /ArtistMusic/Create

        public ActionResult Create()
        {
            var model = new ArtistMusicViewModel()
            {
                ArtistList = artistBiz.ReadArtist().Select(
                x => new SelectListItem { Value = x.ID.ToString(), Text = x.ArtistName }),
                MusicList = musicBiz.ReadMusic().Select(
                x => new SelectListItem { Value = x.ID.ToString(), Text = x.MusicName })
            };
            return View(model);
        }

        //
        // POST: /ArtistMusic/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(ArtistMusicViewModel artist_music)
        {

            if (ModelState.IsValid)
            {
                Artist_Music artMus = new Artist_Music();
                artMus.MusicID = artist_music.MusicID;
                artMus.ArtistID = artist_music.ArtistID;
                artMusicBiz.AddArtistToMusic(artMus);
                return RedirectToAction("Index");
            }


            return View(artist_music);
        }

        //
        // GET: /ArtistMusic/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Artist_Music artist_music = db.Artist_Musics.Find(id);
            if (artist_music == null)
            {
                return HttpNotFound();
            }
            var model = new ArtistMusicViewModel()
            {
                ID = id,
                ArtistList = artistBiz.ReadArtist().Select(
                x => new SelectListItem { Value = x.ID.ToString(), Text = x.ArtistName }),
                ArtistID = artist_music.ArtistID,
                MusicList = musicBiz.ReadMusic().Select(
                x => new SelectListItem { Value = x.ID.ToString(), Text = x.MusicName }),
                MusicID = artist_music.MusicID
            };
            return View(model);
        }

        //
        // POST: /ArtistMusic/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(ArtistMusicViewModel artist_music)
        {
            if (ModelState.IsValid)
            {
                Artist_Music artMus = new Artist_Music();
                artMus.ID = artist_music.ID;
                artMus.MusicID = artist_music.MusicID;
                artMus.ArtistID = artist_music.ArtistID;
                artMusicBiz.EditArtistToMusic(artMus);
                return RedirectToAction("Index");
            }
            return View(artist_music);
        }

        //
        // GET: /ArtistMusic/Delete/5

        public ActionResult Delete(int id = 0)
        {
            Artist_Music artist_music = db.Artist_Musics.Find(id);
            if (artist_music == null)
            {
                return HttpNotFound();
            }
            return View(artist_music);
        }

        //
        // POST: /ArtistMusic/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Artist_Music artist_music = db.Artist_Musics.Find(id);
            db.Artist_Musics.Remove(artist_music);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}