﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataAccess.Models;
using DataAccess;
using Business;
using Lyricstan_V1.ViewModel;

namespace Lyricstan_V1.Controllers
{
    public class ArtistController : Controller
    {
        private LyricContext db = new LyricContext();
        private ArtistBusiness artistBiz = new ArtistBusiness();

        //
        // GET: /Artist/

        public ActionResult Index()
        {
            IEnumerable<Artist> artists = artistBiz.ReadArtist();
            return View(artists);
        }

        //
        // POST: /Artist/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public void Create(ArtistViewModel artist)
        {
            if (ModelState.IsValid)
            {
                Artist art = new Artist();
                art.ID = Guid.NewGuid();
                art.ArtistName = artist.ArtistName;
                art.CountryID = artist.CountryID;
                art.FacebookUrl = artist.FacebookUrl;
                art.pictureUrl = artist.pictureUrl;
                art.TwitterUrl = artist.TwitterUrl;
                art.SiteUrl = artist.SiteUrl;
                artistBiz.AddArtist(art);
            }
        }

        //
        // GET: /Artist/Edit/5


        public ActionResult Edit(Guid id)
        {
            Artist artist = artistBiz.ReadArtist(id);
            if (artist == null)
            {
                return HttpNotFound();
            }

            CountryBusiness countryBiz = new CountryBusiness();
            var model = new ArtistViewModel()
            {
                CountryList = countryBiz.ReadCountries().Select(
                x => new SelectListItem { Value = x.ID.ToString(), Text = x.CountryName }),
                ArtistId=artist.ID,
                CountryID=artist.CountryID,
                ArtistName=artist.ArtistName,
                FacebookUrl=artist.FacebookUrl,
                TwitterUrl=artist.TwitterUrl,
                pictureUrl=artist.pictureUrl,
                SiteUrl=artist.SiteUrl
            };
            return View(model);
        }

        //
        // POST: /Artist/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(ArtistViewModel artist)
        {
            if (ModelState.IsValid)
            {
                Artist art = new Artist();
                art.ID = artist.ArtistId;
                art.ArtistName = artist.ArtistName;
                art.CountryID = artist.CountryID;
                art.FacebookUrl = artist.FacebookUrl;
                art.pictureUrl = artist.pictureUrl;
                art.TwitterUrl = artist.TwitterUrl;
                art.SiteUrl = artist.SiteUrl;
                artistBiz.EditArtist(art);
                return RedirectToAction("Index");
            }
            ViewBag.CountryID = new SelectList(db.Countries, "ID", "CountryName", artist.CountryID);
            return View(artist);
        }

        #region For Ajax
        //Create an Artist object
        [ChildActionOnly]
        public PartialViewResult _Artist()
        {
            CountryBusiness countryBiz = new CountryBusiness();
            var model = new ArtistViewModel()
            {
                CountryList = countryBiz.ReadCountries().Select(
                x => new SelectListItem { Value = x.ID.ToString(), Text = x.CountryName })
            };
            return PartialView(model);
        }
        //Add the artist
        [ValidateAntiForgeryToken]
       public ActionResult _FormArtist(ArtistViewModel artist)
        {
            Create(artist);

            IEnumerable<Artist> artists = artistBiz.ReadArtist();
            return View("Index", artists);
        }

        public PartialViewResult _Search()
        {
            return PartialView();
        }

        public ActionResult SearchForm(string ArtistName)
        {
            IEnumerable<Artist> artist = artistBiz.ReadArtist(ArtistName);

            return View("Index", artist);
        }
        #endregion
    }
}