﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataAccess;
using Business;
using DataAccess.Models;
using System.Web.Security;

namespace Lyricstan_V1.Controllers
{
    public class RateController : Controller
    {

        private RateBusiness rateBiz = new RateBusiness();

        //
        // GET: /Rate/

        public ActionResult Index()
        {
            return View();
        }

        public void CreateRate(Guid musicID, int rateRange)
        {
            Rate rate = new Rate();
            rate.ID = new Guid();
            rate.MusicID = musicID;
            rate.RateNumber = rateRange;
            rate.UserID = (Guid)Membership.GetUser().ProviderUserKey;
            rateBiz.AddRate(rate);
            
        }

    }
}
