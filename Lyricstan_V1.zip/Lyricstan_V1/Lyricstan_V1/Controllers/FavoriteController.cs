﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataAccess;
using DataAccess.Models;
using Business;
using System.Web.Security;

namespace Lyricstan_V1.Controllers
{
    public class FavoriteController : Controller
    {

        private FavoriteBusiness favoriteBiz = new FavoriteBusiness();
        //
        // GET: /Favorite/


        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public void CreatFavorite(Guid MusicId)
        {
            Favorite favorite = new Favorite();
            favorite.ID = new Guid();
            favorite.MusicID = MusicId;
            favorite.UserID = (Guid)Membership.GetUser().ProviderUserKey;
            favoriteBiz.AddFavorite(favorite);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public void DeleteFavorite(Guid FavoriteID)
        {
            favoriteBiz.Deletefavorite(FavoriteID);
        }

    }
}
