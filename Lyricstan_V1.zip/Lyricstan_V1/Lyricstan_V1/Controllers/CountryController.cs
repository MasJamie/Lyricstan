﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataAccess.Models;
using DataAccess;
using Business;

namespace Lyricstan_V1.Controllers
{
    public class CountryController : Controller
    {
        CountryBusiness countryBiz = new CountryBusiness();

        private LyricContext db = new LyricContext();

        //
        // GET: /Country/

        public ActionResult Index(string Search)
        {
            //var connections = (SqlConnection)db.Database.Connection;
            
            if (Search == null)
                return View(db.Countries.ToList());
            return View(countryBiz.SearchCountry(Search));
        }

        //
        // GET: /Country/Details/5

        public void CheckC()
        {
            
            if (countryBiz.ReadCountries(1))
            {
                ViewBag.Message = "yeap";
            }
            ViewBag.Message = "Nope";
        }

        //
        // GET: /Country/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Country country = countryBiz.ReadCountry(id);
            if (country == null)
            {
                return HttpNotFound();
            }
            return View(country);
        }

        //
        // POST: /Country/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Country country)
        {
            if (ModelState.IsValid)
            {
                if (countryBiz.EditCountry(country))
                {
                    return RedirectToAction("Index");
                }
            }
            return View(country);
        }


        #region Add new country with Ajax
        [ChildActionOnly()]
        public PartialViewResult _Country()
        {
            Country country = new Country();
            return PartialView("_Country", country);
        }

        [ValidateAntiForgeryToken()]
        public ActionResult _FormCountry(Country country)
        {
            countryBiz.AddCountry(country);

            IEnumerable<Country> countries = countryBiz.ReadCountries();

            return View("Index", countries);
        }
        #endregion
    }
}