﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataAccess.Models;
using DataAccess;
using Lyricstan_V1.ViewModel;
using Business;

namespace Lyricstan_V1.Controllers
{
    public class MusicController : Controller
    {
        private LyricContext db = new LyricContext();
        private GenreBusiness genreBiz = new GenreBusiness();
        private AlbumeBusiness albumeBiz = new AlbumeBusiness();
        private MusicBusiness musicBiz = new MusicBusiness();

        //
        // GET: /MusicBusiness/

        public ActionResult Index()
        {
            var musics = db.Musics.Include(m => m.Genre).Include(m => m.Albume);
            return View(musics.ToList());
        }

        //
        // POST: /MusicBusiness/Create


        public void Create(MusicViewModel music)
        {
            if (ModelState.IsValid)
            {
                Music mus = new Music();
                mus.ID = Guid.NewGuid();
                mus.AlbumeID = music.AlbumeID;
                mus.GenreID = music.GenreID;
                mus.MusicName = music.MusicName;
                mus.Lyric = music.Lyric;
                mus.PublishDate = music.PublishDate;
                mus.VideoUrl = music.VideoUrl;
                mus.CoverUrl = music.CoverUrl;
                mus.DownloadUrl = music.DownloadUrl;
                musicBiz.AddMusic(mus);
            }
        }

        //
        // GET: /MusicBusiness/Edit/5

        public ActionResult Edit(Guid id)
        {
            Music music = db.Musics.Find(id);
            if (music == null)
            {
                return HttpNotFound();
            }
            var model = new MusicViewModel()
            {
                ID=id,
                GenreList = genreBiz.ReadGenrs().Select(
                x => new SelectListItem { Value = x.ID.ToString(), Text = x.GenreName }),
                GenreID = music.GenreID,
                AlbumeList = albumeBiz.ReadAlbumeForArtist(id).Select(
                x => new SelectListItem { Value = x.ID.ToString(), Text = x.AlbumeName }),
                AlbumeID=music.AlbumeID,
                MusicName=music.MusicName,
                Lyric=music.Lyric,
                PublishDate=music.PublishDate,
                CoverUrl=music.CoverUrl,
                DownloadUrl=music.DownloadUrl,
                VideoUrl=music.VideoUrl
            };
            return View(model);
        }

        //
        // POST: /MusicBusiness/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(MusicViewModel music)
        {
            if (ModelState.IsValid)
            {
                Music mus = new Music();
                mus.ID = music.ID;
                mus.AlbumeID = music.AlbumeID;
                mus.GenreID = music.GenreID;
                mus.MusicName = music.MusicName;
                mus.Lyric = music.Lyric;
                mus.PublishDate = music.PublishDate;
                mus.VideoUrl = music.VideoUrl;
                mus.CoverUrl = music.CoverUrl;
                mus.DownloadUrl = music.DownloadUrl;
                musicBiz.EditMusic(mus);
                return View("ReadMusic", mus);
            }
            return View(music);
        }

        //
        // GET: /MusicBusiness/Delete/5

        public ActionResult Delete(Guid id)
        {
            Music music = db.Musics.Find(id);
            if (music == null)
            {
                return HttpNotFound();
            }
            return View(music);
        }

        //
        // POST: /MusicBusiness/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(Guid id)
        {
            Music music = db.Musics.Find(id);
            db.Musics.Remove(music);
            db.SaveChanges();

            IEnumerable<ShowMusicViewModel> musics = from m in db.Musics
                                                     select new ShowMusicViewModel()
                                                     {
                                                         ID = m.ID,
                                                         MusicName = m.MusicName,
                                                         Artist = m.Albume.Artist.ArtistName,
                                                         Albume = m.Albume.AlbumeName,
                                                         Genre = m.Genre.GenreName,
                                                         CoverUrl = m.CoverUrl,
                                                         Lyric = m.Lyric,
                                                         PublishDate = m.PublishDate
                                                     };
            return View("MusicList",musics);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }

        public ActionResult _Detail(Guid albumeId)
        {
            ViewBag.AlbumeID = albumeId;

            IEnumerable<Music> musics = from m in db.Musics
                                        where m.AlbumeID == albumeId
                                        select m;
            return View("_Detail", musics);
        }

        [ChildActionOnly]
        public PartialViewResult _Music(Guid albumeid)
        {
            MusicViewModel music = new MusicViewModel()
            {
                AlbumeID=albumeid,
                GenreList = genreBiz.ReadGenrs().Select
                (x => new SelectListItem { Value = x.ID.ToString(), Text = x.GenreName })
            };

            return PartialView("_Music", music);
        }

        [ValidateAntiForgeryToken]
        public ActionResult _MusicForm(MusicViewModel music)
        {
            ViewBag.AlbumeID = music.AlbumeID;
            Create(music);

            IEnumerable<Music> musics = from m in db.Musics
                                        where m.AlbumeID == music.AlbumeID
                                        select m;

            return View("_Detail", musics);
        }


        public ActionResult ReadMusic (Guid id)
        {
            Music music = musicBiz.ReadMusic(id);
            
            return View("ReadMusic",music);
        }


    }
}