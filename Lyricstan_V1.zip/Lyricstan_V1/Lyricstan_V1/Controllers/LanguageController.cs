﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataAccess.Models;
using DataAccess;
using Business;

namespace Lyricstan_V1.Controllers
{
    public class LanguageController : Controller
    {
        private LyricContext db = new LyricContext();
        private LanguageBusiness languageBiz = new LanguageBusiness();

        //
        // GET: /LanguageBusiness/

        public ActionResult Index(string Search)
        {
            if (Search == null)
                return View(db.Languages.ToList());
            return View(languageBiz.SearchLanguage(Search));
        }

        //
        // GET: /LanguageBusiness/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /LanguageBusiness/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Language language)
        {
            if (ModelState.IsValid)
            {
                if (languageBiz.AddLanguage(language))
                    return RedirectToAction("Index");
                ViewBag.Message = "This language already exist";
            }

            return View(language);
        }

        //
        // GET: /LanguageBusiness/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Language language = languageBiz.ReadLanguage(id);
            if (language == null)
            {
                return HttpNotFound();
            }
            return View(language);
        }

        //
        // POST: /LanguageBusiness/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Language language)
        {
            if (ModelState.IsValid)
            {
                if (languageBiz.EditLanguage(language))
                    return RedirectToAction("Index");
            }
            return View(language);
        }
    }
}