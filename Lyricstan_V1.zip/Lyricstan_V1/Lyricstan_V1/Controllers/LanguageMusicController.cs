﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataAccess.Models;
using DataAccess;
using Business;
using Lyricstan_V1.ViewModel;


namespace Lyricstan_V1.Controllers
{
    public class LanguageMusicController : Controller
    {
        private LyricContext db = new LyricContext();
        private MusicBusiness musicBiz = new MusicBusiness();
        private LanguageBusiness languageBiz = new LanguageBusiness();
        private LanguageMusicBussiness langMusBiz = new LanguageMusicBussiness();

        //
        // GET: /LanguageMusic/

        public ActionResult Index()
        {
            var language_musics = db.Language_Musics.Include(l => l.Music).Include(l => l.Language);
            return View(language_musics.ToList());
        }

        //
        // GET: /LanguageMusic/Details/5

        public ActionResult Details(Guid id)
        {
            Language_Music language_music = db.Language_Musics.Find(id);
            if (language_music == null)
            {
                return HttpNotFound();
            }
            return View(language_music);
        }

        //
        // POST: /LanguageMusic/Delete/5



        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }

        public PartialViewResult ReadLanguage(Guid Musicid)
        {
            IEnumerable<LanguageMusicViewModel> langMusic = from l in db.Language_Musics
                                                            where l.MusicID == Musicid
                                                            select new LanguageMusicViewModel()
                                                            {
                                                                LanguageName = l.Language.languageName
                                                            };
            return PartialView(langMusic);
        }
   
    
    
    }
}