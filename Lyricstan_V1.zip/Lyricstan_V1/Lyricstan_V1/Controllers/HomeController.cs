﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using DataAccess.Models;
using Business;
using Lyricstan_V1.ViewModel;
using DataAccess;

namespace Lyricstan_V1.Controllers
{
    public class HomeController : Controller
    {
        LyricContext db = new LyricContext();
        Music MusicBiz = new Music();
        
        public ActionResult Index()
        {

            IEnumerable<ShowMusicViewModel> musics = from m in db.Musics
                                                 select new ShowMusicViewModel()
                                                 {
                                                     ID=m.ID,
                                                     MusicName=m.MusicName,
                                                     Artist=m.Albume.Artist.ArtistName,
                                                     Albume=m.Albume.AlbumeName,
                                                     Genre=m.Genre.GenreName,
                                                     CoverUrl=m.CoverUrl,
                                                     Lyric=m.Lyric,
                                                     PublishDate=m.PublishDate
                                                 };


            return View("Index", musics);
        }

        public ActionResult LoginForm()
        {
            return View();
        }

        public ActionResult Login()
        {
            if (Request.Form["txtUserName"] == "Admin" && Request.Form["txtPassword"] == "Admin")
            {
                IEnumerable<ShowMusicViewModel> musics = from m in db.Musics
                                                         select new ShowMusicViewModel()
                                                         {
                                                             ID = m.ID,
                                                             MusicName = m.MusicName,
                                                             Artist = m.Albume.Artist.ArtistName,
                                                             Albume = m.Albume.AlbumeName,
                                                             Genre = m.Genre.GenreName,
                                                             CoverUrl = m.CoverUrl,
                                                             Lyric = m.Lyric,
                                                             PublishDate = m.PublishDate
                                                         };

                FormsAuthentication.SetAuthCookie("Admin", true);

                return View("Index", musics);
            }
            return View("LoginForm");
        }

        public ActionResult _Search(string Search)
        {

            IEnumerable<ShowMusicViewModel> musics = from m in db.Musics
                                                     where m.Lyric.Contains(Search)
                                                     select new ShowMusicViewModel()
                                                     {
                                                         ID = m.ID,
                                                         MusicName = m.MusicName,
                                                         Artist = m.Albume.Artist.ArtistName,
                                                         Albume = m.Albume.AlbumeName,
                                                         Genre = m.Genre.GenreName,
                                                         CoverUrl = m.CoverUrl,
                                                         Lyric = m.Lyric,
                                                         PublishDate = m.PublishDate
                                                     };
            return View("Index", musics);
        }

    }
}
