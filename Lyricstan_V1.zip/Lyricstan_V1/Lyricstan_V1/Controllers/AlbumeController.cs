﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataAccess.Models;
using DataAccess;
using Lyricstan_V1.ViewModel;
using Business;

namespace Lyricstan_V1.Controllers
{
    public class AlbumeController : Controller
    {
        private AlbumeBusiness albumeBiz = new AlbumeBusiness();
        private ArtistBusiness artistBiz = new ArtistBusiness();
        private LyricContext db = new LyricContext();

        //
        // GET: /AlbumeBusiness/

        public ActionResult Index()
        {
            var albumes = db.Albumes.Include(a => a.Artist);
            return View(albumes.ToList());
        }

        //
        // GET: /AlbumeBusiness/Edit/5

        public ActionResult Edit(Guid id)
        {
            Albume albume = albumeBiz.ReadAlbume(id);
            if (albume == null)
            {
                return HttpNotFound();
            }
            var model = new AlbumeViewModel()
            {
                ArtistList = artistBiz.ReadArtist().Select(
                x => new SelectListItem { Value = x.ID.ToString(), Text = x.ArtistName }),
                ID=albume.ID,
                ArtistID = albume.ArtistID,
                AlbumeName = albume.AlbumeName,
                AlbumeArtUrl = albume.AlbumeArtUrl,
                Description = albume.Description,
                PublishYear = albume.PublishYear
            };
            return View(model);
        }

        //
        // POST: /AlbumeBusiness/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(AlbumeViewModel albume)
        {
            if (ModelState.IsValid)
            {
                Albume alb = new Albume();
                alb.ID = albume.ID;
                alb.ArtistID = albume.ArtistID;
                alb.AlbumeName = albume.AlbumeName;
                alb.AlbumeArtUrl = albume.AlbumeArtUrl;
                alb.Description = albume.Description;
                alb.PublishYear = albume.PublishYear;
                albumeBiz.EditAlbume(alb);
                ViewBag.artistID = albume.ArtistID;
                IEnumerable<Albume> albumes = from a in db.Albumes
                                              where a.ArtistID == albume.ArtistID
                                              select a;
                return View("_Detail", albumes);
            }
            return View(albume);
        }

        public ActionResult _Detail(Guid id)
        {
            IEnumerable<Albume> albumes = from a in db.Albumes
                                          where a.ArtistID == id
                                          select a;
            ViewBag.artistID = id;
            return View("_Detail", albumes);
        }

        public PartialViewResult _Albume(Guid id)
        {
            Albume albume = new Albume() { ArtistID = id};

            return PartialView("_Albume", albume);
        }
        [ValidateAntiForgeryToken]
        public ActionResult _AlbumeForm(Albume albume)
        {
            albume.ID = Guid.NewGuid();
            albumeBiz.AddAlbume(albume);

            IEnumerable<Albume> albumes = from a in db.Albumes
                             where a.ArtistID == albume.ArtistID
                             select a;
            ViewBag.artistID = albume.ArtistID;

            return View ("_Detail",albumes);
        }
    }
}