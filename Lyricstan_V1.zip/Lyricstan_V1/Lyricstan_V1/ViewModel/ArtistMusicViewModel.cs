﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Lyricstan_V1.ViewModel
{
    public class ArtistMusicViewModel
    {
        public int ID { get; set; }
        public Guid ArtistID { get; set; }
        public Guid MusicID { get; set; }

        public IEnumerable<SelectListItem> ArtistList { get; set; }
        public IEnumerable<SelectListItem> MusicList { get; set; }
    }
}