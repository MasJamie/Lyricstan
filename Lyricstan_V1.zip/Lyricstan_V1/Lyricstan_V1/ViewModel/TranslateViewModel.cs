﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace Lyricstan_V1.ViewModel
{
    public class TranslateViewModel
    {
        [Key]
        public virtual Guid ID { get; set; }
        [Required]
        public virtual Guid MusicID { get; set; }
        [Required]
        public virtual int LanguageID { get; set; }
        [Required]
        [DataType(DataType.MultilineText)]
        public virtual string LyricTranslate { get; set; }

        public IEnumerable<SelectListItem> MusicList { get; set; }
        public IEnumerable<SelectListItem> LanguageList { get; set; }
    }
}