﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Lyricstan_V1.ViewModel
{
    public class ShowMusicViewModel
    {
        public Guid ID { get; set; }
        public string Genre { get; set; }
        public string Albume { get; set; }
        public string Artist { set; get; }
        [Display(Name = "MusicBusiness")]
        public virtual string MusicName { get; set; }
        public virtual string PublishDate { get; set; }
        [DataType(DataType.ImageUrl)]
        [Display(Name = "Cover pic")]
        public virtual string CoverUrl { get; set; }
        public virtual string Lyric { get; set; }
    }
}