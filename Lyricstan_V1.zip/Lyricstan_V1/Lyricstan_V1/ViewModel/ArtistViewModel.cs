﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DataAccess.Models;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Lyricstan_V1.ViewModel
{
    public class ArtistViewModel
    {

        public int CountryID { get; set; }
        public virtual Guid ArtistId { set; get; }
        [Required]
        [StringLength(30, MinimumLength = 3)]
        [Display(Name = "Artist")]
        public virtual string ArtistName { get; set; }
        [DataType(DataType.Url)]
        [Display(Name = "Facebook")]
        public virtual string FacebookUrl { get; set; }
        [DataType(DataType.Url)]
        [Display(Name = "Twitter")]
        public virtual string TwitterUrl { get; set; }
        [DataType(DataType.ImageUrl)]
        [Display(Name = "Picture")]
        public virtual string pictureUrl { get; set; }
        [DataType(DataType.Url)]
        [Display(Name = "Site")]
        public virtual string SiteUrl { get; set; }

        public IEnumerable<SelectListItem> CountryList { get; set; }

    }
}   