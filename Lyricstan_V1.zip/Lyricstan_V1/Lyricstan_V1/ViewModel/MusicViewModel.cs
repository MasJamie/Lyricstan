﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Lyricstan_V1.ViewModel
{
    public class MusicViewModel
    {
        public Guid ID { get; set; }
        public int GenreID { get; set; }
        public Guid AlbumeID { get; set; }
        [Required]
        [StringLength(30, MinimumLength = 2)]
        [Display(Name = "Music")]
        public virtual string MusicName { get; set; }
        public virtual string PublishDate { get; set; }
        [DataType(DataType.ImageUrl)]
        [Display(Name = "Cover pic")]
        public virtual string CoverUrl { get; set; }
        [DataType(DataType.Url)]
        [Display(Name = "Video Link")]
        public virtual string VideoUrl { get; set; }
        [DataType(DataType.Url)]
        [Display(Name = "Download link")]
        public virtual string DownloadUrl { get; set; }
        [DataType(DataType.MultilineText)]
        [Required]
        public virtual string Lyric { get; set; }

        public IEnumerable<SelectListItem> GenreList { get; set; }
        public IEnumerable<SelectListItem> AlbumeList { get; set; }
    }
}