﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Lyricstan_V1.ViewModel
{
    public class AlbumeViewModel
    {
        public Guid ID { get; set; }
        public Guid ArtistID { get; set; }
        [Display(Name = "AlbumeBusiness")]
        [Required]
        [StringLength(30, MinimumLength = 3)]
        public virtual string AlbumeName { get; set; }
        [Display(Name = "Picture of albume")]
        [DataType(DataType.ImageUrl)]
        public virtual string AlbumeArtUrl { get; set; }
        [Display(Name = "Publish year")]
        public virtual string PublishYear { get; set; }
        [Display(Name = "Description")]
        [StringLength(200)]
        [DataType(DataType.MultilineText)]
        public virtual string Description { get; set; }

        public IEnumerable<SelectListItem> ArtistList { get; set; }
    }
}