﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Business;
using DataAccess.Models;
using DataAccess;
using AutoMapper;
using ServiceAPI.Models;

namespace ServiceAPI.Controllers
{
    public class ValuesController : ApiController
    {

        LyricContext db = new LyricContext();


        public MusicResponse Get()
        {
            MusicResponse musicResponse = new MusicResponse();
            try
            {
                musicResponse.Musics = (from M in db.Musics
                                          select new MusicDTO
                                          {
                                              ID = M.ID,
                                              MusicName = M.MusicName,
                                              Lyric = M.Lyric,
                                              Albume = M.Albume.AlbumeName,
                                              Artist = M.Albume.Artist.ArtistName
                                          }).ToList();
            }
            catch (Exception e)
            {
                throw new HttpResponseException(
                    new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent("An error occurred, please try again"),
                    ReasonPhrase = "Critical exception"
                });
            }

            return musicResponse;
        }

        [HttpGet]
      public MusicResponse Search(string search)
        {
            MusicResponse musicResponse = new MusicResponse();
            try
            {
                musicResponse.Musics = (from M in db.Musics
                                          where M.Lyric.Contains(search)
                                          select new MusicDTO
                                          {
                                              ID = M.ID,
                                              MusicName = M.MusicName,
                                              Lyric = M.Lyric,
                                              Albume = M.Albume.AlbumeName,
                                              Artist = M.Albume.Artist.ArtistName
                                          }).ToList();
            }
            catch (Exception e)
            {
                throw new HttpResponseException(new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent("An error occurred, please try again"),
                    ReasonPhrase = "Critical exception"
                });
            }

            return musicResponse;
        }

        public MusicResponse Get(string id)
        {
            string conv = id;
            Guid musidID=new Guid(conv);
            MusicResponse musicResponse = new MusicResponse();
            try
            {
                musicResponse.Musics = (from M in db.Musics
                                          where M.ID == musidID
                                          select new MusicDTO
                                          {
                                              ID = M.ID,
                                              MusicName = M.MusicName,
                                              Lyric = M.Lyric,
                                              Albume = M.Albume.AlbumeName,
                                              Artist = M.Albume.Artist.ArtistName
                                          }).ToList();
            }
            catch (Exception e)
            {
                throw new HttpResponseException(new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent("An error occurred, please try again"),
                    ReasonPhrase = "Critical exception"
                });
            }

            return musicResponse;
        }

    }
}