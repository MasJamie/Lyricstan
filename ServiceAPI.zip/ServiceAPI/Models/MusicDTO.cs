﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DataAccess.Models;

namespace ServiceAPI.Models
{
    public class MusicDTO
    {
        public Guid ID { get; set; }
        public string Lyric { get; set; }
        public string MusicName { get; set; }
        public string Albume { get; set; }
        public string Artist { get; set; }
    }
}