﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiceAPI.Models
{
    public class MusicResponse
    {
        public List<MusicDTO> Musics { get; set; }
    }
}